"""
validate_population.py -- independent recomputation of the deterministic quantities.

Usage:  python validate_population.py            (a few seconds)
Writes population_results.csv with the quantities quoted in Sections 6 and 7:
  * the population margin gamma for K = 10 lags and cond(M) = 1, 2, 4, 8, 16,
    and for K = 6, cond(M) = 4 (Sections 6.1 and 7.4);
  * the source margin gamma_s for K = 1 (closed form), 5, 6 and 10 (Section 6.1);
  * S_X (Assumption 2, used in Table 2) and the sample size of (6) with delta = 0.1, K = 10.
Margins are computed by the SDP of indep_model.max_margin; each value is the exact smallest
eigenvalue at the returned unit direction, hence a certified lower bound on the margin.
"""
import csv, numpy as np
from indep_model import fixed_model, population_matrices, autocorr_table, max_margin, S_X, P

rows = []
for K, c in [(10, 1), (10, 2), (10, 4), (10, 8), (10, 16), (6, 4)]:
    M, _ = fixed_model(cond=c)
    g, _ = max_margin(population_matrices(M, K))
    rows.append(('gamma', f'K={K};cond={c}', g))
r1 = autocorr_table(1)[:, 1]
rows.append(('gamma_s', 'K=1', max(r1.min(), (-r1).min())))     # K = 1: best sign of the single lag
for K in [5, 6, 10]:
    rho = autocorr_table(K)
    g, _ = max_margin([np.diag(rho[:, k]) for k in range(1, K+1)])
    rows.append(('gamma_s', f'K={K}', g))
M, V = fixed_model()
sx = S_X(M, V)
g10, _ = max_margin(population_matrices(M, 10))
rows.append(('S_X', 'K=10;cond=4', sx))
rows.append(('T_bound_eq6', 'delta=0.1;K=10;cond=4', 10 + 4*(P+1)*10*sx/(0.1*g10**2)))

with open('population_results.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['quantity', 'setting', 'independent_value'])
    for q, s, v in rows: w.writerow([q, s, repr(float(v))])
for q, s, v in rows: print('%-12s %-22s %.8g' % (q, s, v))
print('written: population_results.csv')
