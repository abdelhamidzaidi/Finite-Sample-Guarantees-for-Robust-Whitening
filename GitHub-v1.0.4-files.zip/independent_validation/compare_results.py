"""
compare_results.py -- compares the independent validation with the original results.

Usage:  python compare_results.py ../results
        (the argument is the folder obtained by unzipping ../results.zip)
Reads population_results.csv and mc_T*.csv (written by the two validate_*.py scripts) and the
original stored results (cmpR_*.pkl, res_6_500.pkl; plain Python/NumPy data, read with pickle).
Writes validation_results.csv and prints a summary.

Acceptance rules
  Deterministic quantities: |independent - original| / |original| <= 1e-6, the relative
    tolerance to which the original margins were computed (MNP stopped when its certified
    bracket was below 1e-6). gamma_s for K = 1 and the constants S_X and the sample size are
    compared with the values printed in the manuscript (S_X to 3 significant digits).
  Monte Carlo: for P(A(alpha) PD) the difference independent - original is reported with a
    95% Newcombe (hybrid Wilson score) interval and a two-sided two-proportion z-test; for the
    medians of lambda_min(A(alpha)) and of the whitening defect, the difference of medians with
    a 95% percentile-bootstrap interval (10 000 resamples, seed 0). The comparison passes when
    every interval contains 0. A p-value above 0.05 alone is not evidence of equivalence, so the
    intervals are the primary output: they bound how large a real difference could be.
  The original MMRW output is the minimum-norm-point iterate at relative tolerance 1e-3 (or at
  the iteration cap); the independent MM output is the exact SDP optimum of the same problem.
"""
import sys, os, csv, glob, pickle, numpy as np
from scipy.stats import norm

RES = sys.argv[1] if len(sys.argv) > 1 else os.path.join('..', 'results')
Z = norm.ppf(0.975); rng = np.random.default_rng(0)


def load(name):
    return pickle.load(open(os.path.join(RES, name), 'rb'))


def wilson(k, n):
    p = k/n; d = 1 + Z*Z/n; c = (p + Z*Z/(2*n))/d; h = Z*np.sqrt(p*(1-p)/n + Z*Z/(4*n*n))/d
    return max(0.0, c-h), min(1.0, c+h)


def newcombe(k1, n1, k2, n2):
    """95% interval for p1 - p2 (Newcombe 1998, method 10)."""
    p1, p2 = k1/n1, k2/n2; l1, u1 = wilson(k1, n1); l2, u2 = wilson(k2, n2)
    d = p1 - p2
    return d - np.sqrt((p1-l1)**2 + (u2-p2)**2), d + np.sqrt((u1-p1)**2 + (p2-l2)**2)


def ztest(k1, n1, k2, n2):
    p = (k1+k2)/(n1+n2); se = np.sqrt(p*(1-p)*(1/n1 + 1/n2))
    return 1.0 if se == 0 else 2*(1 - norm.cdf(abs(k1/n1 - k2/n2)/se))


def boot_median_diff(x, y, B=10000):
    x = np.asarray(x); y = np.asarray(y)
    bx = np.median(x[rng.integers(0, len(x), (B, len(x)))], axis=1)
    by = np.median(y[rng.integers(0, len(y), (B, len(y)))], axis=1)
    return np.median(x) - np.median(y), *np.quantile(bx - by, [0.025, 0.975])


out = [['block', 'quantity', 'setting', 'independent', 'original', 'difference', 'rel_difference_or_ci_low',
        'ci_high', 'p_value', 'n_independent', 'n_original', 'criterion', 'pass']]
ok_all = True

# ---------------- deterministic quantities
orig = {('gamma', f'K=10;cond={c}'): load(f'cmpR_cond_{c}.pkl')['gamma'] for c in [1, 2, 4, 8, 16]}
orig[('gamma', 'K=6;cond=4')] = load('res_6_500.pkl')['rho']
printed = {('gamma_s', 'K=1'): (-0.912, 5e-4), ('gamma_s', 'K=5'): (0.0065, 5e-5), ('gamma_s', 'K=6'): (0.0272, 5e-5),
           ('gamma_s', 'K=10'): (0.2005, 5e-5), ('S_X', 'K=10;cond=4'): (6.21, 5e-3),
           ('T_bound_eq6', 'delta=0.1;K=10;cond=4'): (4.35e7, 5e4)}
for q, s, v in csv.reader(open('population_results.csv')):
    if q == 'quantity': continue
    v = float(v)
    if (q, s) in orig:
        o = orig[(q, s)]; rel = abs(v-o)/abs(o); ok = rel <= 1e-6
        out.append(['population', q, s, '%.10g' % v, '%.10g' % o, '%.3e' % (v-o), '%.2e' % rel, '', '', '', '',
                    'relative difference <= 1e-6 (original computed to rel. tol. 1e-6)', ok])
    else:
        o, half = printed[(q, s)]; ok = abs(v-o) <= half
        out.append(['population', q, s, '%.6g' % v, '%g' % o, '%.3e' % (v-o), '', '', '', '', '',
                    'equal to the printed value at its displayed precision (+-%g)' % half, ok])
    ok_all &= ok

# ---------------- Monte Carlo
for f in sorted(glob.glob('mc_T*.csv'), key=lambda x: int(x[4:-4])):
    T = int(f[4:-4]); r = list(csv.DictReader(open(f))); n = len(r)
    orows = load(f'cmpR_T_{T}.pkl')['rows']; no = len(orows)
    for mine, theirs in [('MM', 'MMRW'), ('PC', 'PC')]:
        k1 = sum(int(x[f'{mine}_pd']) for x in r)
        k2 = sum(bool(x[theirs]['ok'] and x[theirs]['truepd']) for x in orows)
        lo, hi = newcombe(k1, n, k2, no); ok = lo <= 0 <= hi
        out.append(['monte_carlo', f'P(PD) {mine} vs {theirs}', f'T={T}', '%.3f' % (k1/n), '%.3f' % (k2/no), '%+.3f' % (k1/n - k2/no),
                    '%+.3f' % lo, '%+.3f' % hi, '%.2f' % ztest(k1, n, k2, no), n, no, '95% Newcombe interval contains 0', ok])
        ok_all &= ok
        for key, okey, lab in [('lmin', 'tl', 'median lambda_min(A(alpha))'), ('defect', 'defect', 'median whitening defect')]:
            x = [float(v[f'{mine}_{key}']) for v in r]; x = [v for v in x if v == v]
            y = [d[theirs][okey] for d in orows if d[theirs]['ok']]; y = [v for v in y if v == v]
            dm, lo, hi = boot_median_diff(x, y); ok = lo <= 0 <= hi
            out.append(['monte_carlo', f'{lab} {mine} vs {theirs}', f'T={T}', '%.4f' % np.median(x), '%.4f' % np.median(y), '%+.4f' % dm,
                        '%+.4f' % lo, '%+.4f' % hi, '', len(x), len(y), '95% bootstrap interval contains 0', ok])
            ok_all &= ok

with open('validation_results.csv', 'w', newline='') as f:
    csv.writer(f).writerows(out)
for row in out[1:]:
    print('%-11s %-48s %-24s indep %-12s orig %-12s diff %-11s [%s, %s] %s %s' % (row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7],
          ('p=' + row[8]) if row[8] else '', 'PASS' if row[12] else 'FAIL'))
print('written: validation_results.csv;  all criteria met:', ok_all)
