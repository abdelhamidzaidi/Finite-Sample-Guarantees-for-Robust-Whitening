# Independent validation of the numerical results

This folder checks the main numerical results of the manuscript with a **separate
implementation**, written from the descriptions in the paper only. It imports nothing from the
repository's own code (`core.py`, `model.py`, ...) and does not use the minimum-norm-point
iteration. It is reported in the last paragraph of Appendix G of the manuscript.

## What is independent
| Ingredient | Repository code | This validation |
|---|---|---|
| AR(2) autocovariances | truncated MA(infinity) expansion | closed form (Yule–Walker recursion) |
| Margin and maximal-margin direction | minimum-norm-point iteration (Algorithms 1, 4) | interior-point SDP solver: CVXPY + Clarabel |
| Data simulator, estimator, PC, whitening defect | `model.py`, `core.py` | own code in `indep_model.py` |
| Random seeds | see Appendix F | `numpy.random.default_rng(20261008 + T)` |

Shared with the repository: only the documented fixed configuration of Section 6.1 (model drawn
once with seed 1), so that the same population quantities are computed.

## Files
| File | Purpose |
|---|---|
| `indep_model.py` | model, estimators, SDP margin, PC and assessment (shared by the scripts) |
| `validate_population.py` | recomputes the margins γ (K = 10, cond(M) = 1, 2, 4, 8, 16; K = 6), the source margins γ_s (K = 1, 5, 6, 10), S_X and the sample size of (6) → `population_results.csv` |
| `validate_monte_carlo.py` | 500 new trials at each of T = 10^3, 10^4, 10^5 (1500 in total) → `mc_T1000.csv`, `mc_T10000.csv`, `mc_T100000.csv` (one row per trial) |
| `compare_results.py` | compares both with the original stored results → `validation_results.csv` |
| `requirements.txt` | exact library versions used |
| `population_results.csv`, `mc_T*.csv`, `validation_results.csv` | the outputs obtained on 8 October 2026 |

## How to run (about one minute)
Python 3.12.3 was used. From this folder:

    pip install -r requirements.txt
    python validate_population.py
    python validate_monte_carlo.py 1000 10000 100000
    # unzip ../results.zip first, which creates the folder ../results
    python compare_results.py ../results

Both validation scripts are deterministic: a second run produced byte-identical CSV files.

## Settings
* Solver: Clarabel 0.11.1 through CVXPY 1.9.3, default settings (feasibility and duality-gap
  tolerances 1e-8). The SDP is: maximize t subject to Σ a_k A_k − t I ⪰ 0 and ‖a‖ ≤ 1.
  Each reported margin is the exact smallest eigenvalue at the returned unit direction.
* Monte Carlo: fixed configuration (K = 10, SNR 5 dB, cond(M) = 4), burn-in 1000 samples,
  PC iteration cap 3000. "MM" is the exact empirical maximal-margin combination (SDP optimum);
  the original "MMRW" approximates it by the minimum-norm-point iteration to relative tolerance 1e-3.

## Acceptance criteria and results (`validation_results.csv`)
* **Population margins γ** (6 values): relative difference from the original values at most
  1e-6, the tolerance to which the original margins were computed. Observed: 8.5e-9 to 8.5e-7.
* **Source margins, S_X, sample size** (6 values): equal to the values printed in the manuscript
  at their displayed precision.
* **Monte Carlo** (6 settings × 3 measures): the difference "independent − original" is
  reported with a 95% interval: Newcombe's interval for P(A(α) PD), and a percentile-bootstrap
  interval (10 000 resamples) for the medians of λ_min(A(α)) and of the whitening defect. The
  criterion is that every interval contains 0. A two-proportion z-test p-value is also reported
  for P(PD); since a large p-value alone does not establish equivalence, the intervals are the
  primary result. They show that any real difference in P(PD) is at most 0.067 in absolute value
  at T = 10^3, at most 0.065 at T = 10^4 and at most 0.017 at T = 10^5.

All 30 criteria were met.
