"""
indep_model.py -- model, estimators and methods of the independent validation.

Written from the descriptions in the manuscript only; nothing is imported from the
repository's own code (core.py, model.py, ...). Deliberate differences from that code:
  * AR(2) autocorrelations and variances in closed form (Yule-Walker recursion),
    instead of a truncated MA(infinity) expansion;
  * the margin gamma and the maximal-margin direction are computed by an interior-point
    semidefinite-programming solver (CVXPY + Clarabel), instead of the minimum-norm-point
    iteration (Algorithms 1 and 4):
        maximize t   subject to   sum_k a_k A_k - t I  positive semidefinite,  ||a||_2 <= 1;
  * own data simulator, lagged-covariance estimator, PC iteration (Algorithm 2) and
    whitening defect; new random seeds (see validate_monte_carlo.py).
The only shared ingredient is the documented fixed configuration of Section 6.1
(p = 5, AR(2) pole radius 0.85 and frequencies 0.35, 0.95, 1.55, 2.15, 2.75, mixing matrix
and noise covariance drawn once with seed 1, SNR 5 dB, cond(M) = 4 unless stated).
"""
import numpy as np
import cvxpy as cp
from scipy.signal import lfilter

P = 5
R_POLE = 0.85
OMEGAS = [0.35, 0.95, 1.55, 2.15, 2.75]
SOLVER = 'CLARABEL'                    # interior-point conic solver, default settings
SOLVER_OPTS = {}                       # Clarabel defaults: feasibility and gap tolerances 1e-8


# ------------------------------------------------------------------ model (Sections 2, 6.1)
def ar2_autocorr(r, w, H):
    """rho(0..H) of s(t) = a1 s(t-1) + a2 s(t-2) + e(t), a1 = 2 r cos(w), a2 = -r^2:
    rho(0) = 1, rho(1) = a1/(1 - a2), rho(h) = a1 rho(h-1) + a2 rho(h-2)."""
    a1, a2 = 2*r*np.cos(w), -r*r
    rho = np.zeros(H+1); rho[0] = 1.0; rho[1] = a1/(1-a2)
    for h in range(2, H+1):
        rho[h] = a1*rho[h-1] + a2*rho[h-2]
    return rho


def ar2_variance(r, w):
    """Variance of the same AR(2) process with unit innovation variance (closed form)."""
    a1, a2 = 2*r*np.cos(w), -r*r
    return (1-a2)/((1+a2)*((1-a2)**2 - a1**2))


def fixed_model(cond=4.0, snr_db=5.0):
    """M = Q1 diag(1, ..., 1/cond) Q2 (Q1, Q2 orthogonal QR factors of Gaussian matrices) and
    V = c G G^t with tr(M M^t)/tr(V) = 10^(SNR/10); drawn once with seed 1 (Section 6.1)."""
    rng = np.random.default_rng(1)
    Q1 = np.linalg.qr(rng.standard_normal((P, P)))[0]
    Q2 = np.linalg.qr(rng.standard_normal((P, P)))[0]
    M = Q1 @ np.diag(np.linspace(1.0, 1.0/cond, P)) @ Q2
    G = rng.standard_normal((P, P)); V = G @ G.T
    V *= np.trace(M @ M.T)/np.trace(V)*10**(-snr_db/10)
    return M, V


def autocorr_table(H):
    """p x (H+1) array of the unit-variance source autocorrelations rho_i(h)."""
    return np.array([ar2_autocorr(R_POLE, w, H) for w in OMEGAS])


def population_matrices(M, K):
    """A_k = M D_k M^t, D_k = diag(rho_1(k), ..., rho_p(k)), k = 1..K (equation (2))."""
    rho = autocorr_table(K)
    return [M @ np.diag(rho[:, k]) @ M.T for k in range(1, K+1)]


def S_X(M, V, H=400):
    """S_X = sum_h ||Gamma_X(h)||_F^2 (Assumption 2), lags |h| <= H."""
    rho = autocorr_table(H)
    tot = np.linalg.norm(M @ np.diag(rho[:, 0]) @ M.T + V, 'fro')**2
    for h in range(1, H+1):
        tot += 2*np.linalg.norm(M @ np.diag(rho[:, h]) @ M.T, 'fro')**2
    return tot


# ------------------------------------------------------------------ margin by SDP
def max_margin(As):
    """Return (gamma, alpha): gamma = max_{||a|| <= 1} lambda_min(sum_k a_k A_k), evaluated
    exactly at the returned unit direction alpha (so it is a certified lower bound)."""
    K = len(As); p = As[0].shape[0]
    a = cp.Variable(K); t = cp.Variable()
    S = sum(a[k]*As[k] for k in range(K))
    prob = cp.Problem(cp.Maximize(t), [(S + S.T)/2 - t*np.eye(p) >> 0, cp.norm(a, 2) <= 1])
    prob.solve(solver=SOLVER, **SOLVER_OPTS)
    alpha = np.asarray(a.value).ravel(); alpha /= np.linalg.norm(alpha)
    gamma = np.linalg.eigvalsh(np.tensordot(alpha, np.stack(As), 1))[0]
    return gamma, alpha


# ------------------------------------------------------------------ data and methods (Sections 4, 7)
def simulate(M, V, T, rng, burn=1000):
    """X = M S + N: unit-variance AR(2) sources (burn-in discarded), Gaussian white noise."""
    S = np.empty((P, T))
    for i, w in enumerate(OMEGAS):
        e = rng.standard_normal(T + burn)
        S[i] = lfilter([1.0], [1.0, -2*R_POLE*np.cos(w), R_POLE**2], e)[burn:]/np.sqrt(ar2_variance(R_POLE, w))
    return M @ S + np.linalg.cholesky(V) @ rng.standard_normal((P, T))


def lagged_estimates(X, K):
    """hat A_k = sym( (T-k)^{-1} sum_t X(t+k) X(t)^t ), k = 1..K (Section 4)."""
    T = X.shape[1]; out = []
    for k in range(1, K+1):
        G = X[:, k:] @ X[:, :T-k].T/(T-k)
        out.append((G + G.T)/2)
    return out


def pc(As, cap=3000):
    """PC (Algorithm 2): alpha <- alpha + g(u)/||g(u)||, u a unit eigenvector for
    lambda_min(A(alpha)), started at (tr A_k)_k; returns None if not PD within the cap."""
    St = np.stack(As); a = np.array([np.trace(A) for A in As]); a /= np.linalg.norm(a)
    for _ in range(cap):
        w, U = np.linalg.eigh(np.tensordot(a, St, 1))
        if w[0] > 0:
            return a
        u = U[:, 0]; g = np.array([u @ A @ u for A in As]); a = a + g/np.linalg.norm(g)
    return None


def assess(alpha, As_true, As_hat):
    """(A(alpha) PD?, lambda_min(A(alpha)), whitening defect ||hat Q A(alpha) hat Q - I||_2)
    for the unit direction alpha, with hat Q = hat A(alpha)^{-1/2} (left side of (5))."""
    a = alpha/np.linalg.norm(alpha)
    B = np.tensordot(a, np.stack(As_true), 1); Bh = np.tensordot(a, np.stack(As_hat), 1)
    lt = np.linalg.eigvalsh(B)[0]; w, U = np.linalg.eigh(Bh)
    defect = np.nan
    if w[0] > 0:
        Qh = U @ np.diag(w**-0.5) @ U.T
        defect = np.linalg.norm(Qh @ B @ Qh - np.eye(P), 2)
    return bool(lt > 0), lt, defect
